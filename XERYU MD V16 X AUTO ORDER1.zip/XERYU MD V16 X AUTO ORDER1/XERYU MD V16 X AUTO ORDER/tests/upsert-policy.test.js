'use strict'

const test = require('node:test')
const assert = require('node:assert/strict')
const {
    timestampToSeconds,
    getMessageTimestampSeconds,
    isCommandCandidate,
    shouldProcessLiveAppendMessage,
    shouldAllowAppendFallback
} = require('../source/upsert-policy')

test('normalizes common Baileys timestamp representations', () => {
    assert.equal(timestampToSeconds(1_800_000_000), 1_800_000_000)
    assert.equal(timestampToSeconds(1_800_000_000_000), 1_800_000_000)
    assert.equal(timestampToSeconds({ low: 1_800_000_000, high: 0 }), 1_800_000_000)
    assert.equal(getMessageTimestampSeconds({ messageTimestamp: { toNumber: () => 1_800_000_000 } }), 1_800_000_000)
    assert.equal(getMessageTimestampSeconds({}), 0)
})

test('recognizes private aliases and configured group prefixes', () => {
    assert.equal(isCommandCandidate('menu', '628123456789@s.whatsapp.net'), true)
    assert.equal(isCommandCandidate('help', 'abc123@lid'), true)
    assert.equal(isCommandCandidate('halo', '628123456789@s.whatsapp.net'), false)
    assert.equal(isCommandCandidate('!store', '120363000000@g.us', '!'), true)
    assert.equal(isCommandCandidate('x!store', '120363000000@g.us', 'x!'), true)
})

test('permits only recent command append events created after socket open', () => {
    const now = Math.floor(Date.now() / 1000)
    const socketOpenedAt = now - 5
    const liveMessage = {
        key: { remoteJid: '628123456789@s.whatsapp.net', id: 'live-1' },
        messageTimestamp: now - 2
    }
    assert.equal(shouldProcessLiveAppendMessage(liveMessage, socketOpenedAt, '.menu'), true)
    assert.equal(shouldProcessLiveAppendMessage(liveMessage, 0, '.menu'), false)
    assert.equal(shouldProcessLiveAppendMessage({ ...liveMessage, messageTimestamp: socketOpenedAt - 1 }, socketOpenedAt, '.menu'), false)
    assert.equal(shouldProcessLiveAppendMessage({ key: liveMessage.key }, socketOpenedAt, '.menu'), false)
    assert.equal(shouldProcessLiveAppendMessage(liveMessage, socketOpenedAt, 'just chatting'), false)
})

test('accepts a same-ID append fallback only when the first event was not a command', () => {
    assert.equal(shouldAllowAppendFallback({ upsertType: 'notify', isCommand: false }, 'append', true), true)
    assert.equal(shouldAllowAppendFallback({ upsertType: 'notify', isCommand: true }, 'append', true), false)
    assert.equal(shouldAllowAppendFallback({ upsertType: 'append', isCommand: false }, 'append', true), false)
    assert.equal(shouldAllowAppendFallback({ upsertType: 'notify', isCommand: false }, 'notify', true), false)
    assert.equal(shouldAllowAppendFallback({ upsertType: 'notify', isCommand: false }, 'append', false), false)
})
