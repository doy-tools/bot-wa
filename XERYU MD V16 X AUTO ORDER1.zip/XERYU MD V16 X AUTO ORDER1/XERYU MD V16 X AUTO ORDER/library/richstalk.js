'use strict'

const fs = require('fs')
const path = require('path')
const fetch = require('node-fetch')
const yts = require('yt-search')
const { sendRichHtmlDocument } = require('./richhtml.js')

const PAGE_FILE = path.join(__dirname, 'richhtml-pages', 'richstalk-v16.html')
const UA = 'Mozilla/5.0 (Xeryuu-MD RichStalk/16.0; +https://github.com/)'

function safeJson(value) {
    return JSON.stringify(value)
        .replace(/</g, '\\u003c')
        .replace(/>/g, '\\u003e')
        .replace(/&/g, '\\u0026')
        .replace(/\u2028/g, '\\u2028')
        .replace(/\u2029/g, '\\u2029')
}

function cleanUsername(value) {
    const raw = String(value || '').trim()
    try {
        if (/^https?:\/\//i.test(raw)) {
            const u = new URL(raw)
            const host = u.hostname.toLowerCase().replace(/^www\./, '')
            const parts = u.pathname.split('/').filter(Boolean)
            const first = parts[0] || ''
            if (['instagram.com', 'tiktok.com', 't.me'].includes(host)) {
                return String(first).replace(/^@/, '')
            }
            if (['youtube.com', 'm.youtube.com', 'music.youtube.com'].includes(host)) {
                if (first.startsWith('@')) return first.slice(1)
                if (['channel', 'user', 'c'].includes(first.toLowerCase())) return String(parts[1] || '')
            }
        }
    } catch {}
    return raw.replace(/^@+/, '').split(/[/?#\s]/)[0]
}

function formatNumber(value) {
    if (value === undefined || value === null || value === '') return ''
    const n = Number(value)
    if (!Number.isFinite(n)) return String(value)
    return new Intl.NumberFormat('id-ID', { notation: 'compact', maximumFractionDigits: 1 }).format(n)
}

async function fetchWithTimeout(url, options = {}, timeoutMs = 15000) {
    const controller = new AbortController()
    const timer = setTimeout(() => controller.abort(), timeoutMs)
    try {
        return await fetch(url, { ...options, signal: controller.signal })
    } catch (error) {
        if (error?.name === 'AbortError') throw new Error(`Permintaan ke provider timeout setelah ${Math.round(timeoutMs / 1000)} detik.`)
        throw error
    } finally {
        clearTimeout(timer)
    }
}

async function getJson(url, options = {}) {
    const { timeoutMs = 15000, ...requestOptions } = options || {}
    const response = await fetchWithTimeout(url, {
        ...requestOptions,
        headers: {
            'user-agent': UA,
            'accept': 'application/json,text/plain,*/*',
            ...(requestOptions.headers || {})
        },
        redirect: 'follow'
    }, Number(timeoutMs) || 15000)
    const raw = await response.text()
    let data = null
    try { data = JSON.parse(raw) } catch {}
    if (!response.ok) throw new Error(data?.message || data?.error || `HTTP ${response.status}`)
    if (data === null) throw new Error('Respons provider bukan JSON yang valid.')
    return data
}

async function getText(url, options = {}) {
    const { timeoutMs = 15000, ...requestOptions } = options || {}
    const response = await fetchWithTimeout(url, {
        ...requestOptions,
        headers: {
            'user-agent': UA,
            'accept': 'text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8',
            'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
            ...(requestOptions.headers || {})
        },
        redirect: 'follow'
    }, Number(timeoutMs) || 15000)
    const text = await response.text()
    if (!response.ok) throw new Error(`HTTP ${response.status}`)
    return { text, url: String(response.url || url) }
}

function meta(html, name) {
    const re = new RegExp(`<meta[^>]+(?:property|name)=["']${name.replace(/[.*+?^${}()|[\\]\\\\]/g, '\\$&')}["'][^>]+content=["']([^"']*)["'][^>]*>`, 'i')
    const alt = new RegExp(`<meta[^>]+content=["']([^"']*)["'][^>]+(?:property|name)=["']${name.replace(/[.*+?^${}()|[\\]\\\\]/g, '\\$&')}["'][^>]*>`, 'i')
    return re.exec(html)?.[1] || alt.exec(html)?.[1] || ''
}

function decodeHtml(value) {
    return String(value || '')
        .replace(/&amp;/g, '&')
        .replace(/&quot;/g, '"')
        .replace(/&#39;/g, "'")
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>')
        .trim()
}

function recursiveFind(root, predicate, maxDepth = 14, depth = 0) {
    if (depth > maxDepth || root === null || root === undefined) return null
    if (predicate(root)) return root
    if (typeof root !== 'object') return null
    for (const value of Object.values(root)) {
        const hit = recursiveFind(value, predicate, maxDepth, depth + 1)
        if (hit !== null) return hit
    }
    return null
}

function extractJsonScript(html, id) {
    const re = new RegExp(`<script[^>]+id=["']${id}["'][^>]*>([\\s\\S]*?)</script>`, 'i')
    const raw = re.exec(html)?.[1]
    if (!raw) return null
    try { return JSON.parse(raw) } catch { return null }
}

async function stalkYouTube(query) {
    const raw = String(query || '').trim()
    if (!raw) throw new Error('Masukkan nama channel, @handle, atau URL channel YouTube.')

    let channel = null
    let channelUrl = ''
    let searchTerm = cleanUsername(raw)
    const exactHandle = raw.match(/(?:youtube\.com\/(?:@|c\/|user\/))([^/?#]+)/i)
    const channelId = raw.match(/youtube\.com\/channel\/([A-Za-z0-9_-]+)/i)
    try {
        if (/^https?:\/\//i.test(raw)) {
            const u = new URL(raw)
            const host = u.hostname.toLowerCase().replace(/^www\./, '')
            if (['youtube.com', 'm.youtube.com', 'music.youtube.com'].includes(host)) {
                const parts = u.pathname.split('/').filter(Boolean)
                if (parts[0]?.startsWith('@')) {
                    searchTerm = parts[0].slice(1)
                    channelUrl = `https://www.youtube.com/@${encodeURIComponent(searchTerm)}`
                } else if (parts[0]?.toLowerCase() === 'channel' && parts[1]) {
                    searchTerm = parts[1]
                    channelUrl = `https://www.youtube.com/channel/${encodeURIComponent(parts[1])}`
                } else if (['user', 'c'].includes(String(parts[0] || '').toLowerCase()) && parts[1]) {
                    searchTerm = parts[1]
                    channelUrl = `https://www.youtube.com/${parts[0].toLowerCase()}/${encodeURIComponent(parts[1])}`
                } else {
                    throw new Error('Gunakan URL channel YouTube, bukan URL video.')
                }
            } else {
                throw new Error('URL harus berasal dari youtube.com.')
            }
        }
    } catch (error) {
        if (/^https?:\/\//i.test(raw)) throw error
    }
    if (!channelUrl && exactHandle) {
        searchTerm = exactHandle[1]
        channelUrl = `https://www.youtube.com/@${encodeURIComponent(searchTerm)}`
    } else if (!channelUrl && channelId) {
        searchTerm = channelId[1]
        channelUrl = `https://www.youtube.com/channel/${encodeURIComponent(searchTerm)}`
    }

    // Query URL langsung terlebih dahulu supaya URL channel tidak berubah menjadi
    // query teks "https:" dan tidak memilih channel orang lain secara acak.
    if (channelUrl) {
        const direct = await yts(channelUrl).catch(() => null)
        channel = Array.isArray(direct?.channels) ? direct.channels[0] : null
    }
    if (!channel) {
        const search = await yts({ query: searchTerm, hl: 'id', gl: 'ID' })
        const channels = Array.isArray(search?.channels) ? search.channels : []
        const wanted = String(searchTerm || '').replace(/^@/, '').toLowerCase()
        channel = channels.find(item => {
            const url = String(item?.url || item?.link || '').toLowerCase()
            const name = String(item?.name || '').toLowerCase()
            return (wanted && (url.endsWith(`/@${wanted}`) || url.endsWith(`/channel/${wanted}`) || name === wanted))
        }) || channels[0] || null
    }
    if (!channel) throw new Error('Channel YouTube tidak ditemukan. Pastikan username atau URL channel benar.')

    channelUrl = String(channel.url || channel.link || channelUrl || '')
    let stats = {}
    try {
        const { text: page } = await getText(channelUrl, { timeoutMs: 12000 })
        const sub = page.match(/"subscriberCountText"\s*:\s*\{[^}]*?"simpleText"\s*:\s*"([^"]+)"/)?.[1]
        const videos = page.match(/"videoCountText"\s*:\s*\{[^}]*?"runs"\s*:\s*\[\s*\{\s*"text"\s*:\s*"([^"]+)"/)?.[1]
        const desc = page.match(/"description"\s*:\s*\{[^}]*?"simpleText"\s*:\s*"([^"]*)"/)?.[1]
        stats = { subscribers: sub || '', videos: videos || '', description: desc || '' }
    } catch {}

    return {
        platform: 'youtube',
        platformName: 'YouTube',
        username: String(channel.name || searchTerm || raw),
        displayName: String(channel.name || searchTerm || raw),
        verified: false,
        avatar: String(channel.image || channel.thumbnail || channel.avatar || channel.icon || ''),
        bio: String(stats.description || 'Deskripsi channel tidak berhasil dibaca dari halaman publik.'),
        stats: [
            ['Subscribers', stats.subscribers || 'Tidak tersedia'],
            ['Video', stats.videos || 'Tidak tersedia']
        ],
        url: channelUrl || `https://www.youtube.com/results?search_query=${encodeURIComponent(raw)}`,
        note: 'Data berasal dari informasi publik YouTube. Statistik yang dibatasi YouTube mungkin tidak tersedia.'
    }
}

async function stalkInstagram(username) {
    const user = cleanUsername(username)
    if (!/^[A-Za-z0-9._]{1,30}$/.test(user)) throw new Error('Username Instagram tidak valid.')
    const { text } = await getText(`https://www.instagram.com/${encodeURIComponent(user)}/`)
    const title = decodeHtml(meta(text, 'og:title'))
    const description = decodeHtml(meta(text, 'og:description'))
    const avatar = meta(text, 'og:image')
    const privateAccount = /private account/i.test(description) || /akun privat/i.test(description)

    const followers = text.match(/"edge_followed_by"\s*:\s*\{\s*"count"\s*:\s*(\d+)/)?.[1]
    const following = text.match(/"edge_follow"\s*:\s*\{\s*"count"\s*:\s*(\d+)/)?.[1]
    const media = text.match(/"edge_owner_to_timeline_media"\s*:\s*\{\s*"count"\s*:\s*(\d+)/)?.[1]
    const verified = /"is_verified"\s*:\s*true/i.test(text)

    return {
        platform: 'instagram', platformName: 'Instagram', username: user,
        displayName: title.replace(/\s*\(@[^)]*\).*$/i, '').replace(/\s*\|.*$/,'').trim() || user,
        verified,
        avatar,
        bio: description || (privateAccount ? 'Akun privat. Detail profil publik terbatas.' : 'Tidak ada bio publik.'),
        stats: [
            ['Followers', followers ? formatNumber(followers) : 'Tidak tersedia'],
            ['Following', following ? formatNumber(following) : 'Tidak tersedia'],
            ['Posts', media ? formatNumber(media) : 'Tidak tersedia']
        ],
        url: `https://www.instagram.com/${user}/`,
        note: privateAccount ? 'Akun privat: hanya metadata publik yang dapat ditampilkan.' : 'Data berasal dari halaman profil publik Instagram.'
    }
}

async function stalkTikTok(username) {
    const user = cleanUsername(username)
    if (!/^[A-Za-z0-9._]{1,24}$/.test(user)) throw new Error('Username TikTok tidak valid.')
    const { text } = await getText(`https://www.tiktok.com/@${encodeURIComponent(user)}`)
    const data = extractJsonScript(text, '__UNIVERSAL_DATA_FOR_REHYDRATION__')
    let profile = null
    if (data) {
        const hit = recursiveFind(data, value => value && typeof value === 'object' && value.userInfo && value.userInfo.user)
        profile = hit?.userInfo || null
        if (!profile) {
            const direct = recursiveFind(data, value => value && typeof value === 'object' && value.uniqueId === user)
            profile = direct ? { user: direct, stats: {} } : null
        }
    }

    const u = profile?.user || {}
    const s = profile?.stats || {}
    const title = decodeHtml(meta(text, 'og:title'))
    const description = decodeHtml(meta(text, 'og:description'))

    return {
        platform: 'tiktok', platformName: 'TikTok', username: String(u.uniqueId || user),
        displayName: String(u.nickname || title || user),
        verified: Boolean(u.verified),
        avatar: String(u.avatarLarger || u.avatarMedium || u.avatarThumb || u.avatar || meta(text, 'og:image') || ''),
        bio: String(u.signature || description || 'Tidak ada bio publik.'),
        stats: [
            ['Followers', s.followerCount !== undefined ? formatNumber(s.followerCount) : 'Tidak tersedia'],
            ['Following', s.followingCount !== undefined ? formatNumber(s.followingCount) : 'Tidak tersedia'],
            ['Likes', s.heartCount !== undefined ? formatNumber(s.heartCount) : 'Tidak tersedia'],
            ['Videos', s.videoCount !== undefined ? formatNumber(s.videoCount) : 'Tidak tersedia']
        ],
        url: `https://www.tiktok.com/@${user}`,
        note: 'Data berasal dari informasi publik halaman TikTok.'
    }
}

async function stalkRoblox(username) {
    const raw = String(username || '').trim()
    if (!raw) throw new Error('Masukkan username Roblox.')
    let userId = /^\d+$/.test(raw) ? raw : ''
    let data = null
    if (userId) {
        data = await getJson(`https://users.roblox.com/v1/users/${userId}`)
    } else {
        const lookup = await getJson('https://users.roblox.com/v1/usernames/users', {
            method: 'POST', headers: { 'content-type': 'application/json' },
            body: JSON.stringify({ usernames: [raw.replace(/^@/, '')], excludeBannedUsers: false })
        })
        data = lookup?.data?.[0]
        if (!data?.id) throw new Error('User Roblox tidak ditemukan.')
        userId = String(data.id)
        data = await getJson(`https://users.roblox.com/v1/users/${userId}`)
    }

    let avatar = ''
    try {
        const thumb = await getJson(`https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=${encodeURIComponent(userId)}&size=420x420&format=Png&isCircular=false`)
        avatar = String(thumb?.data?.[0]?.imageUrl || '')
    } catch {}

    return {
        platform: 'roblox', platformName: 'Roblox', username: String(data?.name || raw),
        displayName: String(data?.displayName || data?.name || raw), verified: Boolean(data?.hasVerifiedBadge),
        avatar, bio: String(data?.description || 'Tidak ada deskripsi publik.'),
        stats: [
            ['User ID', String(data?.id || userId)],
            ['Dibuat', data?.created ? new Date(data.created).toLocaleDateString('id-ID') : 'Tidak tersedia'],
            ['Status', data?.isBanned ? 'Banned' : 'Aktif / tidak terdeteksi banned']
        ],
        url: `https://www.roblox.com/users/${userId}/profile`,
        note: 'Data pengguna diambil dari endpoint publik Roblox.'
    }
}

async function stalkTelegram(username) {
    const user = cleanUsername(username)
    if (!/^[A-Za-z0-9_]{5,32}$/.test(user)) throw new Error('Username Telegram tidak valid atau terlalu pendek.')
    const { text, url } = await getText(`https://t.me/${encodeURIComponent(user)}`)
    const title = decodeHtml(meta(text, 'og:title')) || decodeHtml((text.match(/<div class="tgme_page_title[^>]*>\s*<span[^>]*>([\s\S]*?)<\/span>/i)?.[1] || '').replace(/<[^>]+>/g, ''))
    const description = decodeHtml(meta(text, 'og:description')) || decodeHtml((text.match(/<div class="tgme_page_description[^>]*>([\s\S]*?)<\/div>/i)?.[1] || '').replace(/<[^>]+>/g, ' '))
    const extra = decodeHtml((text.match(/<div class="tgme_page_extra">([\s\S]*?)<\/div>/i)?.[1] || '').replace(/<[^>]+>/g, ' '))
    const avatar = meta(text, 'og:image')
    if (!title && !description) throw new Error('Profil Telegram publik tidak ditemukan atau tidak dapat diakses.')

    return {
        platform: 'telegram', platformName: 'Telegram', username: `@${user}`,
        displayName: title || `@${user}`, verified: false, avatar,
        bio: description || 'Tidak ada deskripsi publik.',
        stats: [['Info publik', extra || 'Tidak tersedia']],
        url: url || `https://t.me/${user}`,
        note: 'Hanya profil publik Telegram yang dapat diperiksa; chat privat tidak diakses.'
    }
}

async function stalkMlbb(query) {
    const raw = String(query || '').trim()
    const parts = raw.split(/[|\s:]+/).filter(Boolean)
    const gameId = String(parts[0] || '').trim()
    const zoneId = String(parts[1] || '').trim()
    if (!/^\d+$/.test(gameId) || !/^\d+$/.test(zoneId)) {
        throw new Error('Format MLBB: .stalkml userId|zoneId  (contoh: .stalkml 134972929|2687)')
    }

    const endpoint = String(global.mlbbStalkConfig?.endpoint || 'https://api.zapi.ink/v1/games:mlbb/profile').trim()
    const apiKey = String(global.mlbbStalkConfig?.apiKey || '').trim()
    if (!apiKey) {
        throw new Error('MLBB stalk belum dikonfigurasi. Isi global.mlbbStalkConfig.apiKey di settings.js. Provider default memerlukan API key.')
    }

    const url = new URL(endpoint)
    url.searchParams.set('gameId', gameId)
    url.searchParams.set('zoneId', zoneId)
    const payload = await getJson(url.toString(), { headers: { 'x-api-key': apiKey } })
    const d = payload?.data || payload
    if (!d || (!d.username && !d.gameId)) throw new Error('Akun MLBB tidak ditemukan atau provider menolak permintaan.')

    const role = Array.isArray(d.roles) ? d.roles : []
    return {
        platform: 'mlbb', platformName: 'Mobile Legends', username: String(d.username || 'Tidak tersedia'),
        displayName: String(d.username || 'Mobile Legends'), verified: Boolean(d.verified), avatar: String(d.avatar || d.avatarUrl || d.avatar_url || d.profile?.avatar || d.profile?.avatarUrl || d.profile?.avatar_url || d.user?.avatar || d.user?.avatarUrl || d.user?.avatar_url || ''),
        bio: role.length ? role.map(x => String(x?.name || x?.role || x)).join(' • ') : 'Data rank/role tambahan tidak tersedia dari provider.',
        stats: [['User ID', gameId], ['Zone ID', zoneId], ['Status', d.verified ? 'Terverifikasi provider' : 'Terbaca'], ['Game', 'Mobile Legends (MLBB)']],
        url: `https://www.mobilelegends.com/`,
        note: 'Data diperoleh dari provider stalk MLBB yang dikonfigurasi di bot.'
    }
}

const HANDLERS = Object.freeze({ youtube: stalkYouTube, instagram: stalkInstagram, tiktok: stalkTikTok, mlbb: stalkMlbb, roblox: stalkRoblox, telegram: stalkTelegram })

async function stalk(platform, query) {
    const key = String(platform || '').toLowerCase().trim()
    const handler = HANDLERS[key]
    if (!handler) throw new Error(`Platform stalk tidak dikenal: ${platform}`)
    return handler(query)
}

async function sendRichStalk(conn, chat, platform, query) {
    const data = await stalk(platform, query)
    const html = fs.readFileSync(PAGE_FILE, 'utf8').replace('__XERYUU_STALK_BOOTSTRAP__', safeJson(data))
    return sendRichHtmlDocument(conn, chat, {
        html,
        title: `Xeryuu Stalk • ${data.displayName || data.username}`,
        cooldownKey: `stalk:${platform}`,
        withVerification: false
    })
}

module.exports = { stalk, sendRichStalk, stalkYouTube, stalkInstagram, stalkTikTok, stalkMlbb, stalkRoblox, stalkTelegram }
