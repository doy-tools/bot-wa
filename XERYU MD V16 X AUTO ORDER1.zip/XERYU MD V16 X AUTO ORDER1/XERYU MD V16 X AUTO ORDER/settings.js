//Please don't change script credit creator
//🔰 Creator : Xvdoyz
//🔰 Telegram : https://t.me/doyzz9
//🔰 Nomor Whatsapp : 6281999294528
//🔰 ©xvdoyzdev
// JANGAN MENGUBAH CREDIT DARI SCRIPT INI, JIKA KETAHUAN MAKA AKAN DIKENAKAN SANKSI DAN KONSEKUENSI ©xnalz
const fs = require('fs');
const chalk = require('chalk');

const { version } = require("./package.json")

// Opsional: userhash akun Catbox untuk upload terautentikasi. Kosongkan untuk anonim.
global.catboxUserHash = ''

//api groq bot
global.groqApiKey = String(process.env.GROQ_API_KEY || '').trim()

global.tokens = String("6ff2b5120dd7bb71f8859eb58495c91911daf16243ce7b6172d1f3b767846ef3").split(",").map(x => x.trim()).filter(Boolean)

//~~~~~ Settings Bot (bisa diubah) ~~~~~~~//
global.owner = '6281999294528'
global.botnumber = '6285881599723'
global.versi = version 
global.namaOwner = "Xvdoyz"
global.packname = 'doyz'
global.author = '©xvdoyz'
global.botname = 'xv-bot'
global.namebot = 'xv-bot'
global.botname2 = 'xv-bot'


//~~~~~~~~~ Settings Auto Adzan / Auto Sholat ~~~~~~~~~//
// Jadwal diambil harian dari API MyQuran yang bersumber dari data Kemenag RI.
// Ganti citySearch dengan nama kota/kabupaten yang tersedia di API.
global.autoSholatConfig = {
    citySearch: 'JAKARTA PUSAT',
    timezone: 'Asia/Jakarta',
    apiBaseUrl: 'https://api.myquran.com/v3/sholat',
    adzanAudioUrl: 'https://media.vocaroo.com/mp3/1ofLT2YUJAjQ',
    closeDurationMs: 5 * 60 * 1000,
    apiTimeoutMs: 10000,
    retryApiMs: 5 * 60 * 1000
}

global.telegramConfig = {
    enabled: true,
    botToken: "",
    startImageUrl: "https://files.catbox.moe/1fe13g.jpg",

    forceJoinEnabled: true,
    forceJoinChannel: "@Xnalzz",
    forceJoinUrl: "https://t.me/XnalzNotDev",
    forceJoinTitle: "Channel Xeryuu",
    adminIds: String('7022774592').split(',').map(x => x.trim()).filter(Boolean),
    maintenance: false,
    ownerNotifyChannel: ''
}

global.antiDeletePrivateUsers = [
    global.owner,
    ''
].filter(Boolean)

//~~~~~ Settings Link ~~~~~~~~~//
global.vercelToken = ""
global.linkOwner = "https://wa.me/6281999294528"
global.linkGrup = "https://chat.whatsapp.com/DZbIsT5m63zJ9XXEMDS8Tl"

//~~~~ Settings Jeda Jpm ~~~~~~~~~~//
global.delayJpm = 3500
global.delayPushkontak = 6000

//~~~~~~ Settings Transaksi (Done/proses) ~~~~~~~~~//
global.linkSaluran = "https://whatsapp.com/channel/0029VbE7yLIHAdNVc76b2n19"
global.linkGroup = "" //grub kalo gpunya hpus aja
global.idSaluran = "https://whatsapp.com/channel/0029VbE7yLIHAdNVc76b2n19"
global.namaSaluran = "DOYY FAMILY"

//~~~~~~~~~ Settings NasionalPay ~~~~~~~~//.
global.nasionalPayConfig = {
    enabled: true,
    baseUrl: "https://merchant.nasionalpay.com/api/payment",
    storeKey: "",
    minAmount: 1000,
    maxAmount: 10000000,
    expiresInMinutes: 10,
    pollIntervalMs: 5000,
    timeoutMs: 20000,
    routes: {
        create: "/generate",
        status: "/status",
        cancel: "/cancel"
    }
}

//~~~~~~~~~ Settings Top Up VIPayment ~~~~~~~~~//
global.topupConfig = {
    enabled: true,
    apiId: "mki3wFNX",          // API ID VIPayment
    apiKey: "",         // API KEY VIPayment
    baseUrl: "https://vip-reseller.co.id/api",
    priceLevel: "basic", // basic / premium / special
    markup: 1000,
    markupPercent: 0,
    priceCacheMs: 5 * 60 * 1000,
    timeout: 20000
}


//~~~~~~~~~ Settings Nokos RuangOTP ~~~~~~~~~//
global.nokosConfig = {
    // API RuangOTP memakai header x-user-id (lihat API Dev Center).
    // Isi userId dengan USER ID akun dari panel RuangOTP, bukan mengira API key selalu sama.
    // IP publik VPS juga wajib didaftarkan di Profile -> Whitelist IP.
    // Nilai apiKey tidak dikirim kecuali sendApiKeyHeader diaktifkan sesuai instruksi provider.
    enabled: true,
    providerName: "RuangOTP",
    baseUrl: "https://api.ruangotp.net/api",
    apiKey: "",
    userId: "",
    apiVersion: "v2",
    markup: 1000,
    markupPercent: 0,
    defaultCountry: 6,
    defaultService: "wa",
    defaultProviderId: "",
    timeoutMs: 20000,
    otpTimeoutMs: 20 * 60 * 1000,
    pollIntervalMs: 5000,
    cacheMs: 60 * 1000,
    minRequestIntervalMs: 750,
    routes: {
        countries: "/country-v2/list",
        services: "/services-v2/list",
        price: "/cekharga-v2/info",
        order: "/order-v2/buy",
        status: "/order-v2/check-status",
        cancel: "/order-v2/cancel",
        resend: "/order-v2/resend"
    }
}

//~~~~~~~~~ Settings Deposit QRIS API ~~~~~~~~~//
//~~~~~~~~~ Settings Convert Pulsa PesanJasa ~~~~~~~~~//
// API key tidak ditampilkan ke pengguna. Rekomendasi: set environment
// PESANJASA_CONVERT_API_KEY pada VPS/PM2. Alternatif: ganti fallback '' pada baris apiKey
// dengan 'API_KEY_ANDA' di VPS pribadi. Jangan bagikan settings.js yang berisi key.
global.convertPulsaConfig = {
    enabled: true,
    providerName: 'PesanJasa',
    baseUrl: 'https://pesanjasa.com/api/v1/convert-pulsa',
    apiKey: String(process.env.PESANJASA_CONVERT_API_KEY || '').trim(),
    timeoutMs: 20000,
    pollIntervalMs: 30000,
    sessionTtlMs: 15 * 60 * 1000,
}

global.depositConfig = {
    enabled: Boolean(global.nasionalPayConfig?.enabled),
    defaultProvider: "nasionalpay",
    minAmount: Number(global.nasionalPayConfig?.minAmount || 1000),
    maxAmount: Number(global.nasionalPayConfig?.maxAmount || 10000000),
    expiresInMinutes: Number(global.nasionalPayConfig?.expiresInMinutes || 10),
    timeoutMs: Number(global.nasionalPayConfig?.timeoutMs || 20000),
    pollIntervalMs: Number(global.nasionalPayConfig?.pollIntervalMs || 5000),
    providers: {
        nasionalpay: {
            name: "NasionalPay",
            driver: "nasionalpay",
            enabled: Boolean(global.nasionalPayConfig?.enabled),
            baseUrl: String(global.nasionalPayConfig?.baseUrl || "https://merchant.nasionalpay.com/api/payment"),
            storeKey: String(global.nasionalPayConfig?.storeKey || "").trim(),
            minAmount: Number(global.nasionalPayConfig?.minAmount || 1000),
            maxAmount: Number(global.nasionalPayConfig?.maxAmount || 10000000),
            expiresInMinutes: Number(global.nasionalPayConfig?.expiresInMinutes || 10),
            timeoutMs: Number(global.nasionalPayConfig?.timeoutMs || 20000),
            pollIntervalMs: Number(global.nasionalPayConfig?.pollIntervalMs || 5000),
            routes: {
                create: global.nasionalPayConfig?.routes?.create || "/generate",
                status: global.nasionalPayConfig?.routes?.status || "/status",
                cancel: global.nasionalPayConfig?.routes?.cancel || "/cancel"
            }
        }
    }
}

//~~~~~~~~~ Settings Store Panel & Sewa Bot ~~~~~~~~~//
global.storeConfig = {
    enabled: true,
    notifyOwner: true,
    monitorIntervalMs: 5 * 60 * 1000
}
global.storeProducts = {
    panel1gb: {
        type: 'panel',
        category: 'Pterodactyl Panel',
        name: 'Panel Pterodactyl 1GB',
        price: 2000,
        stock: 20, // Stok awal; ubah angka ini jika ingin menambah persediaan.
        description: 'Akses panel/server Pterodactyl RAM 1GB'
    },
    panel2gb: {
        type: 'panel',
        category: 'Pterodactyl Panel',
        name: 'Panel Pterodactyl 2GB',
        price: 4000,
        stock: 20,
        description: 'Akses panel/server Pterodactyl RAM 2GB'
    },
    panel4gb: {
        type: 'panel',
        category: 'Pterodactyl Panel',
        name: 'Panel Pterodactyl 4GB',
        price: 6000,
        stock: 20,
        description: 'Akses panel/server Pterodactyl RAM 4GB'
    },
    panel8gb: {
        type: 'panel',
        category: 'Pterodactyl Panel',
        name: 'Panel Pterodactyl Unlimited',
        price: 4000,
        stock: 20,
        description: 'Akses panel/server Pterodactyl RAM Unlimited'
    },
    sewabot: {
        type: 'rental',
        category: 'Sewa Bot',
        name: 'Sewa Bot Otomatis 7D',
        price: 4000,
        stock: 20,
        durationDays: 7,
        description: 'Bot sewa grup untuk memenuhi kebutuhan kamu'
    },
    sewabot15d: {
        type: 'rental',
        category: 'Sewa Bot',
        name: 'Sewa Bot Otomatis 15D',
        price: 7000,
        stock: 20,
        durationDays: 15,
        description: 'Bot sewa grup untuk memenuhi kebutuhan kamu'
    },
    sewabot30d: {
        type: 'rental',
        category: 'Sewa Bot',
        name: 'Sewa Bot Otomatis 30D',
        price: 10000,
        stock: 20,
        durationDays: 30,
        description: 'Bot sewa grup untuk memenuhi kebutuhan kamu'
    }
}

// CEO Jasher: isi JID/nomor CEO di sini bila berbeda dari owner.
global.ceoJids = []

//~~~~~~~~~~ Settings VPS Auto-Order (DigitalOcean) ~~~~~~~~~~//
// Token VPS dipisah dari API Panel Pterodactyl. Jangan isi token panel di sini.
// Ambil Personal Access Token DigitalOcean yang memiliki izin droplet:create dan droplet:read.
global.vpsConfig = {
    enabled: true,
    provider: "digitalocean",
    apiBaseUrl: "https://api.digitalocean.com/v2",
    apiToken: "", // Personal Access Token DigitalOcean, bukan PTLA/PTLC
    region: "sgp1", // Singapore; ganti jika region ini tidak tersedia di akun
    image: "ubuntu-24-04-x64",
    backups: false,
    ipv6: true,
    tags: ["xeryuu-auto-order"],
    readyTimeoutMs: 180000,
    pollIntervalMs: 5000,
    sizeOptions: {
        r1c1: "s-1vcpu-1gb",
        r2c1: "s-1vcpu-2gb",
        r2c2: "s-2vcpu-2gb",
        r4c2: "s-2vcpu-4gb",
        r8c4: "s-4vcpu-8gb",
        r16c4: "s-4vcpu-16gb-amd"
    }
}
// Alias untuk kompatibilitas dengan fitur lama yang masih membaca apiDigitalOcean.
global.apiDigitalOcean = String(global.vpsConfig.apiToken || "").trim()
global.apiSimpleBot = "simplebotz85"

//~~~~~~~~~ Settings Payment ~~~~~~~~~//
global.dana = "089663152244"
global.ovo = "-"
global.gopay = "-"

//~~~~~~~ Settings Store (Bisa Diubah) ~~~~~~~~~~//
global.image = {
ReplyStore: ""
}
global.listProduk = [
  `New Rilis Script Xeryuu-Md V9*
Fitur : MD X BUGS
Total Fitur : 1022+

berbagai fitur tools seperti downloadder sticker dan fitur langka lainnya. ada juga fitur jaga grub 
fitur antikudeta yang cocok buat grupmu tidak diambil alih admin sembarangan
fitur Rpg yang bisa kamu mainkan
fitur bug anti kenon target auto c1
seperti delay invisible+sedot kuota.
ada juga fitur bug grub/attack grup
Pas Masih Lebaran gass order script nya pumpung ada duit dan keburu harga naik.
HARGA P,O : 30K
HARGA RILIS : 35K
OPEN ALL TITLE JUGA
(free update)
*Contact me :*
t.me/XnalzNotDev (telegram)

•BENEFIT PARTNER SPECIAL KELPIN:•
DM TELE AJA KALO PENASARAN BENEFIT`
]
global.vercelToken = ""
//~~~~~~~~~ Settings AUTO ORDER PANEL Pterodactyl ~~~~~~~~~//
// Konfigurasi Panel terpisah dari VPS DigitalOcean di atas.
// domain: URL panel, contoh https://panel.domainkamu.com (tanpa garis miring di akhir)
// apikey: Application API Key / PTLA, dipakai membuat user dan server panel.
// capikey: Client API Key / PTLC, dipakai fitur panel lama yang membaca status/resource client.
global.panelConfig = {
    enabled: true,
    domain: "https://begoluanj.webserverku.biz.id",
    apikey: "ptlc_HHIxGskQ9Ri0EkQQkRqVOAAmwNfKhJ9bh5Gc6NGFTd4",
    capikey: "ptla_fmIGBSKAT0941z6X7EdN5vveOElyYZiVlwLDyZpRHBI",
    nestId: 5,
    eggId: 15,
    locationId: 1
}
global.mlbbStalkConfig = {
    endpoint: "https://api.zapi.ink/v1/games:mlbb/profile",
    apiKey: ""
}
global.richApiConfig = {
    host: "0.0.0.0",
    port: 3001,
    publicUrl: ""
}
global.runtimeConfig = {
    logLevel: "silent",
    waVersion: "2,3000,1044539926",
    botPassword: "",
    pairingNumber: "",
    pairingCustomCode: ""
}

//~~~~~~~~~ Alias kompatibilitas command panel lama ~~~~~~~~~//
// Ubah kredensial hanya di global.panelConfig agar konfigurasi tidak dobel.
global.egg = String(global.panelConfig.eggId) // Egg ID
global.nestid = String(global.panelConfig.nestId) // Nest ID
global.loc = String(global.panelConfig.locationId) // Location ID
global.domain = String(global.panelConfig.domain || "").trim()
global.richApiUrl = "" // URL publik API Rich dapat diisi langsung di settings.js

//~~~~~~~~~ Settings Spotify Rich ~~~~~~~~~//
global.spotifyConfig = {
    enabled: true,
    clientId: '',
    clientSecret: '',
    market: 'ID'
}

global.apikey = String(global.panelConfig.apikey || "").trim() // PTLA: Application API Key
global.capikey = String(global.panelConfig.capikey || "").trim() // PTLC: Client API Key

//~~~~~~~~ Settings Api Panel 2 ~~~~~~~~//
global.eggV2 = "15" // Egg ID
global.nestidV2 = "5" // nest ID
global.locV2 = "1" // Location ID
global.domainV2 = "id"
global.apikeyV2 = "id" //ptla
global.capikeyV2 = "id" //ptlc

//~~~~~~~ Settings Api Subdomain ~~~~~~~//
global.subdomain = {
"serverku.biz.id": {
"zone": "4e4feaba70b41ed78295d2dcc090dd3a", 
"apitoken": ""
}, 
"privatserver.my.id": {
"zone": "699bb9eb65046a886399c91daacb1968", 
"apitoken": ""
}, 
"panelwebsite.biz.id": {
"zone": "2d6aab40136299392d66eed44a7b1122", 
"apitoken": ""
}, 
"mypanelstore.web.id": {
"zone": "c61c442d70392500611499c5af816532", 
"apitoken": ""
}, 
"pteroserver.us.kg": {
"zone": "f693559a94aebc553a68c27a3ffe3b55", 
"apitoken": ""
}, 
"digitalserver.us.kg": {
"zone": "df13e6e4faa4de9edaeb8e1f05cf1a36", 
"apitoken": ""
}, 
"shopserver.us.kg": {
"zone": "54ca38e266bfdf2dcdb7f51fd79c2db5", 
"apitoken": ""
}
}

//~~~~~~~~~~ Settings Message ~~~~~~~~//
global.mess = {
	owner: "```kamu bukan owner untuk menjalankan command ini```",
	admin: "```kamu bukan admin, sebaiknya sadar diri, rendahan```",
	botAdmin: "```kalo bot admin, udah aku ambil tindakan```",
	group: "```bot hanya bisa dijalankan di grup saja, tidak bisa dipakai pribadi karena owner mengkhususkan hanya grup```",
	private: "```bot hanya bisa dipakai di chat pribadi```",
	prem: "```fitur ini khusus premium, jika kamu ingin menjadi user premium, silahkan ketik .developer```",
	wait: 'Loading...',
	error: 'Error!',
	done: 'Done'
}
global.vircsetz = ['☼', '✘', '✦', '✧', '❀', '○', '⏣', '♧', '々', '〆', '✎'] // Emoticon
global.rpg = {
    emoticon(string) {
        string = string.toLowerCase()
        let emot = {
            level: '📊',
            limit: '🎫',
            health: '❤️',
            exp: '✨',
            atm: '💳',
            money: '💰',
            bank: '🏦',
            potion: '🥤',
            diamond: '💎',
            common: '📦',
            uncommon: '🛍️',
            mythic: '🎁',
            legendary: '🗃️',
            superior: '💼',
            pet: '🔖',
            trash: '🗑',
            armor: '🥼',
            sword: '⚔️',
            makanancentaur: "🥗",
            makanangriffin: "🥙",
            makanankyubi: "🍗",
            makanannaga: "🍖",
            makananpet: "🥩",
            makananphonix: "🧀",
            pickaxe: '⛏️',
            fishingrod: '🎣',
            wood: '🪵',
            rock: '🪨',
            string: '🕸️',
            horse: '🐴',
            cat: '🐱',
            dog: '🐶',
            fox: '🦊',
            robo: '🤖',
            petfood: '🍖',
            iron: '⛓️',
            gold: '🪙',
            emerald: '❇️',
            upgrader: '🧰',
            bibitanggur: '🌱',
            bibitjeruk: '🌿',
            bibitapel: '☘️',
            bibitmangga: '🍀',
            bibitpisang: '🌴',
            anggur: '🍇',
            jeruk: '🍊',
            apel: '🍎',
            mangga: '🥭',
            pisang: '🍌',
            botol: '🍾',
            kardus: '📦',
            kaleng: '🏮',
            plastik: '📜',
            gelas: '🧋',
            chip: '♋',
            umpan: '🪱',
            naga: "🐉",
            phonix: "🦅",
            kyubi: "🦊",
            griffin: "🦒",
            centaur: "🎠",
            skata: '🧩'
        }
        let results = Object.keys(emot).map(v => [v, new RegExp(v, 'gi')]).filter(v => v[1].test(string))
        if (!results.length) return ''
        else return emot[results[0][0]]
    }
}
//UPPPPPP
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})